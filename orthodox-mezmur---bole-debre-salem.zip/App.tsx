
import React, { useState, useEffect, useMemo } from 'react';
import { MEZMURS } from './data';
import { Mezmur, Theme } from './types';
import {
  Search,
  Moon,
  Sun,
  ChevronRight,
  Info,
  BookOpen,
  Copy,
  Check,
  Type as TypeIcon,
  Plus,
  Minus,
  LayoutGrid,
  List,
  ArrowLeft,
  Sparkles,
  Music,
  Heart
} from 'lucide-react';

const App: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [theme, setTheme] = useState<Theme>(
    window.matchMedia('(prefers-color-scheme: dark)').matches ? Theme.DARK : Theme.LIGHT
  );
  const [fontSize, setFontSize] = useState<number>(20);
  const [copied, setCopied] = useState(false);
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('grid');

  const filteredMezmurs = useMemo(() => {
    const query = searchQuery.toLowerCase().trim();
    if (!query) return MEZMURS;

    const numQuery = parseInt(query);
    const searchTerms = query.split(/\s+/);

    return MEZMURS.filter(m => {
      if (!isNaN(numQuery) && m.id === numQuery) return true;
      const content = (m.title + ' ' + m.lyrics.join(' ')).toLowerCase();
      return searchTerms.every(term => content.includes(term));
    });
  }, [searchQuery]);

  const currentMezmur = useMemo(() => {
    return MEZMURS.find(m => m.id === selectedId) || null;
  }, [selectedId]);

  const toggleTheme = () => {
    setTheme(prev => prev === Theme.LIGHT ? Theme.DARK : Theme.LIGHT);
  };

  useEffect(() => {
    const root = document.documentElement;
    if (theme === Theme.DARK) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  const handleSelectMezmur = (id: number) => {
    setSelectedId(id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const copyToClipboard = () => {
    if (!currentMezmur) return;
    const text = `${currentMezmur.title}\n\n${currentMezmur.lyrics.join('\n')}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const isDark = theme === Theme.DARK;

  return (
    <div className={`min-h-screen transition-all duration-700 ${isDark ? 'bg-[#0a0a0f]' : 'bg-gradient-to-br from-blue-50 via-slate-50 to-indigo-50'}`}>

      {/* Background Image */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        {/* Main Background Image */}
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat transition-all duration-700"
          style={{
            backgroundImage: 'url(/bg.png)',
            opacity: isDark ? 0.6 : 0.25,
            filter: isDark ? 'none' : 'grayscale(30%) contrast(1.1) brightness(1.1)'
          }}
        />

        {/* Overlay for readability */}
        <div className={`absolute inset-0 transition-all duration-700 ${isDark
          ? 'bg-gradient-to-b from-[#0a0a0f]/80 via-[#0a0a0f]/90 to-[#0a0a0f]'
          : 'bg-gradient-to-b from-slate-50/80 via-slate-50/90 to-slate-50'
          }`} />

        {/* Additional animated effects */}
        {isDark ? (
          <>
            <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] bg-gradient-to-br from-purple-900/20 via-blue-900/10 to-transparent rounded-full blur-[100px] animate-float" />
            <div className="absolute bottom-[-20%] right-[-10%] w-[50%] h-[50%] bg-gradient-to-tl from-amber-900/15 via-orange-900/10 to-transparent rounded-full blur-[100px] animate-float-delayed" />
          </>
        ) : (
          <>
            <div className="absolute top-[-10%] right-[-5%] w-[40%] h-[40%] bg-gradient-to-bl from-blue-200/30 via-indigo-100/20 to-transparent rounded-full blur-[80px] animate-float" />
            <div className="absolute bottom-[-10%] left-[-5%] w-[45%] h-[45%] bg-gradient-to-tr from-slate-200/20 via-purple-100/10 to-transparent rounded-full blur-[80px] animate-float-delayed" />
          </>
        )}
      </div>

      {/* Header */}
      <header className={`sticky top-0 z-50 backdrop-blur-2xl border-b transition-all duration-500 ${isDark
        ? 'bg-[#0a0a0f]/80 border-white/5'
        : 'bg-white/80 border-slate-200/50'
        }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <div className="flex items-center gap-4">
              {selectedId !== null && (
                <button
                  onClick={() => setSelectedId(null)}
                  className={`p-2 rounded-xl transition-all duration-300 ${isDark
                    ? 'hover:bg-white/10 text-white/60 hover:text-white'
                    : 'hover:bg-black/5 text-black/40 hover:text-black'
                    }`}
                >
                  <ArrowLeft size={20} />
                </button>
              )}
              <div className="flex items-center gap-3">
                <div className={`p-2.5 rounded-2xl ${isDark
                  ? 'bg-gradient-to-br from-amber-500/20 to-orange-600/20 border border-amber-500/20'
                  : 'bg-gradient-to-br from-blue-100/50 to-indigo-100/50 border border-blue-200/50'
                  }`}>
                  <Music className={isDark ? 'text-amber-400' : 'text-blue-900'} size={22} />
                </div>
                <div>
                  <h1 className={`text-xl font-bold tracking-tight ${isDark ? 'text-amber-50' : 'text-slate-900'}`}>
                    Mezmur <span className={isDark ? "text-amber-500" : "text-blue-700"}>Collection Center</span>
                  </h1>
                  <p className={`text-[10px] uppercase tracking-[0.2em] font-medium ${isDark ? 'text-amber-200/60' : 'text-slate-500'}`}>
                    Bole Debre Salem
                  </p>
                </div>
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center gap-3">
              {/* View Toggle */}
              <div className={`hidden sm:flex items-center p-1.5 rounded-2xl border transition-all ${isDark
                ? 'bg-white/5 border-white/10'
                : 'bg-slate-100/80 border-slate-200/50'
                }`}>
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2 rounded-xl transition-all duration-300 ${viewMode === 'grid'
                    ? isDark ? 'bg-white/15 text-white shadow-lg' : 'bg-white text-gray-900 shadow-md'
                    : isDark ? 'text-white/40 hover:text-white' : 'text-black/40 hover:text-black'
                    }`}
                >
                  <LayoutGrid size={16} />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-2 rounded-xl transition-all duration-300 ${viewMode === 'list'
                    ? isDark ? 'bg-white/15 text-white shadow-lg' : 'bg-white text-gray-900 shadow-md'
                    : isDark ? 'text-white/40 hover:text-white' : 'text-black/40 hover:text-black'
                    }`}
                >
                  <List size={16} />
                </button>
              </div>

              {/* Theme Toggle */}
              <button
                onClick={toggleTheme}
                className={`p-3 rounded-2xl transition-all duration-500 group ${isDark
                  ? 'bg-gradient-to-br from-amber-500/20 to-orange-600/10 hover:from-amber-500/30 hover:to-orange-600/20 border border-amber-500/20'
                  : 'bg-white hover:bg-slate-50 border border-slate-200 shadow-sm'
                  }`}>
                {isDark ? (
                  <Sun size={18} className="text-amber-400 group-hover:rotate-45 transition-transform duration-500" />
                ) : (
                  <Moon size={18} className="text-slate-700 group-hover:-rotate-12 transition-transform duration-500" />
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">

        {selectedId === null ? (
          /* Collection View */
          <div className="space-y-10 animate-fadeIn">

            {/* Search Section */}
            <div className="max-w-2xl mx-auto">
              <div className={`relative group`}>
                <div className={`absolute -inset-1 rounded-3xl blur-xl opacity-0 group-hover:opacity-100 transition-all duration-500 ${isDark ? 'bg-gradient-to-r from-amber-500/20 via-purple-500/20 to-blue-500/20' : 'bg-gradient-to-r from-blue-200/50 via-indigo-200/50 to-slate-200/50'
                  }`} />
                <div className={`relative flex items-center gap-4 px-6 py-4 rounded-2xl border transition-all duration-300 ${isDark
                  ? 'bg-white/5 border-white/10 focus-within:border-amber-500/50 focus-within:bg-white/10'
                  : 'bg-white/90 border-slate-200 focus-within:border-blue-300 focus-within:shadow-xl focus-within:shadow-blue-100/50'
                  }`}>
                  <Search size={20} className={isDark ? 'text-white/40' : 'text-black/30'} />
                  <input
                    type="text"
                    placeholder="Search hymns by number or title..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className={`flex-1 bg-transparent outline-none text-lg ${isDark ? 'text-white placeholder:text-white/30' : 'text-slate-900 placeholder:text-slate-400'
                      }`}
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery('')}
                      className={`p-1.5 rounded-lg transition-colors ${isDark ? 'hover:bg-white/10 text-white/40' : 'hover:bg-black/5 text-black/40'}`}
                    >
                      ✕
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Header */}
            <div className="flex items-end justify-between">
              <div>
                <div className="flex items-center gap-3 mb-3">
                  <Sparkles className={`${isDark ? 'text-amber-400' : 'text-blue-600'}`} size={20} />
                  <span className={`text-xs font-semibold uppercase tracking-[0.2em] ${isDark ? 'text-amber-400/80' : 'text-blue-700'}`}>
                    Sacred Collection
                  </span>
                </div>
                <h2 className={`text-4xl sm:text-5xl font-bold tracking-tight ${isDark ? 'text-white' : 'text-slate-900'}`}>
                  Our Hymns
                </h2>
                <p className={`mt-2 text-lg ${isDark ? 'text-white/70' : 'text-slate-600'}`}>
                  {filteredMezmurs.length} sacred songs to explore
                </p>
              </div>
            </div>

            {/* Grid */}
            <div className={`
              ${viewMode === 'grid'
                ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6'
                : 'flex flex-col gap-3 max-w-3xl'
              }
            `}>
              {filteredMezmurs.map((mezmur, index) => (
                <div
                  key={mezmur.id}
                  onClick={() => handleSelectMezmur(mezmur.id)}
                  className={`group cursor-pointer relative overflow-hidden transition-all duration-500 ${viewMode === 'grid'
                    ? `rounded-3xl p-6 sm:p-8 hover:-translate-y-2 hover:shadow-2xl ${isDark
                      ? 'bg-gradient-to-br from-white/[0.08] to-white/[0.02] border border-white/10 hover:border-amber-500/30 hover:shadow-amber-500/10'
                      : 'bg-white/90 backdrop-blur-sm border border-slate-100 hover:border-blue-300 hover:shadow-blue-100/50'
                    }`
                    : `rounded-2xl p-5 flex items-center gap-6 hover:translate-x-2 ${isDark
                      ? 'bg-white/5 border border-white/5 hover:bg-white/10 hover:border-amber-500/20'
                      : 'bg-white border border-slate-100 hover:bg-slate-50 hover:shadow-lg'
                    }`
                    }`}
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  {/* Hover gradient overlay */}
                  <div className={`absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 ${isDark
                    ? 'bg-gradient-to-br from-amber-500/10 via-transparent to-purple-500/10'
                    : 'bg-gradient-to-br from-blue-50 via-transparent to-indigo-50/50'
                    }`} />

                  {/* Number */}
                  <div className={`relative z-10 ${viewMode === 'grid' ? 'mb-6' : ''}`}>
                    <span className={`font-bold tracking-tight transition-all duration-300 ${viewMode === 'grid'
                      ? `text-6xl sm:text-7xl ${isDark
                        ? 'text-white/10 group-hover:text-amber-500/40'
                        : 'text-slate-200 group-hover:text-blue-500/20'
                      }`
                      : `text-3xl ${isDark ? 'text-white/20' : 'text-slate-200'}`
                      }`}>
                      {String(mezmur.id).padStart(2, '0')}
                    </span>
                  </div>

                  {/* Title */}
                  <div className={`relative z-10 ${viewMode === 'list' ? 'flex-1' : ''}`}>
                    <h3 className={`font-bold ethiopic-font leading-tight transition-colors ${viewMode === 'grid'
                      ? `text-xl sm:text-2xl ${isDark ? 'text-white group-hover:text-amber-100' : 'text-slate-900'}`
                      : `text-lg ${isDark ? 'text-white/90' : 'text-slate-800'}`
                      }`}>
                      {mezmur.title}
                    </h3>
                    {viewMode === 'grid' && (
                      <p className={`mt-3 text-sm line-clamp-2 ${isDark ? 'text-white/60' : 'text-slate-500'}`}>
                        {mezmur.lyrics[0]}...
                      </p>
                    )}
                  </div>

                  {/* Arrow indicator */}
                  <div className={`${viewMode === 'grid' ? 'absolute bottom-6 right-6' : ''} z-10 transition-all duration-300 ${isDark
                    ? 'text-white/20 group-hover:text-amber-400'
                    : 'text-slate-300 group-hover:text-blue-600'
                    } ${viewMode === 'grid' ? 'opacity-0 translate-x-2 group-hover:opacity-100 group-hover:translate-x-0' : ''}`}>
                    <ChevronRight size={viewMode === 'grid' ? 24 : 20} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          /* Reading View with Sidebar */
          <div className="animate-fadeIn flex gap-8">

            {/* Sidebar - Hymn List */}
            <aside className={`hidden lg:block w-80 flex-shrink-0 sticky top-28 self-start max-h-[calc(100vh-8rem)] overflow-hidden rounded-3xl ${isDark
              ? 'bg-gradient-to-br from-white/[0.06] to-white/[0.02] border border-white/10'
              : 'bg-white/90 backdrop-blur-xl border border-slate-200 shadow-xl shadow-blue-100/20'
              }`}>
              {/* Sidebar Header */}
              <div className={`p-5 border-b ${isDark ? 'border-white/10' : 'border-slate-200/50'}`}>
                <div className="flex items-center gap-3">
                  <BookOpen size={18} className={isDark ? 'text-amber-400' : 'text-blue-600'} />
                  <h3 className={`text-sm font-bold uppercase tracking-[0.15em] ${isDark ? 'text-white/60' : 'text-slate-500'}`}>
                    All Hymns
                  </h3>
                </div>
              </div>

              {/* Sidebar List */}
              <div className="overflow-y-auto max-h-[calc(100vh-14rem)] p-3 custom-scrollbar">
                {MEZMURS.map((mezmur) => (
                  <button
                    key={mezmur.id}
                    onClick={() => handleSelectMezmur(mezmur.id)}
                    className={`w-full text-left px-4 py-3 rounded-xl mb-1 transition-all duration-300 flex items-center gap-4 group ${selectedId === mezmur.id
                      ? isDark
                        ? 'bg-gradient-to-r from-amber-500/20 to-orange-600/10 border border-amber-500/30 text-white'
                        : 'bg-gradient-to-r from-slate-100 to-blue-50 border border-slate-200 text-blue-900 shadow-sm'
                      : isDark
                        ? 'hover:bg-white/5 text-white/60 hover:text-white border border-transparent'
                        : 'hover:bg-white hover:text-blue-700 border border-transparent hover:border-slate-100 shadow-sm'
                      }`}
                  >
                    <span className={`text-xs font-bold w-7 h-7 flex items-center justify-center rounded-lg transition-colors ${selectedId === mezmur.id
                      ? isDark ? 'bg-amber-500/30 text-amber-300' : 'bg-blue-100 text-blue-700'
                      : isDark ? 'bg-white/10 text-white/40 group-hover:bg-white/20' : 'bg-slate-100 text-slate-500 group-hover:bg-slate-200'
                      }`}>
                      {mezmur.id}
                    </span>
                    <span className="flex-1 truncate ethiopic-font text-sm font-medium">
                      {mezmur.title}
                    </span>
                    {selectedId === mezmur.id && (
                      <div className={`w-1.5 h-1.5 rounded-full ${isDark ? 'bg-amber-400' : 'bg-blue-500'}`} />
                    )}
                  </button>
                ))}
              </div>
            </aside>

            {/* Main Reading Content */}
            <div className="flex-1 min-w-0">

              {/* Reading Card */}
              <article className={`relative overflow-hidden rounded-[2.5rem] transition-all duration-500 ${isDark
                ? 'bg-gradient-to-br from-white/[0.08] to-white/[0.02] border border-white/10 shadow-2xl shadow-black/50'
                : 'bg-white border border-slate-100 shadow-2xl shadow-blue-100/10'
                }`}>

                {/* Decorative top gradient */}
                <div className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r ${isDark
                  ? 'from-amber-500 via-orange-500 to-purple-500'
                  : 'from-blue-500 via-indigo-500 to-purple-500'
                  }`} />

                <div className="p-8 sm:p-12 lg:p-16">

                  {/* Header */}
                  <div className="flex flex-wrap items-start justify-between gap-6 mb-12">
                    {/* Number Badge */}
                    <div className={`flex items-center gap-4 px-6 py-4 rounded-2xl ${isDark
                      ? 'bg-gradient-to-br from-amber-500/20 to-orange-600/10 border border-amber-500/20'
                      : 'bg-slate-50 border border-slate-200'
                      }`}>
                      <span className={`text-xs font-bold uppercase tracking-widest ${isDark ? 'text-amber-400/70' : 'text-slate-500'}`}>
                        Hymn
                      </span>
                      <span className={`text-4xl font-bold ${isDark ? 'text-amber-400' : 'text-blue-700'}`}>
                        {String(currentMezmur?.id).padStart(2, '0')}
                      </span>
                    </div>

                    {/* Controls */}
                    <div className="flex items-center gap-2">
                      <div className={`flex items-center rounded-xl border ${isDark ? 'bg-white/5 border-white/10' : 'bg-slate-100 border-slate-200'
                        }`}>
                        <button
                          onClick={() => setFontSize(Math.max(16, fontSize - 2))}
                          className={`p-3 transition-colors ${isDark ? 'hover:bg-white/10 text-white/60' : 'hover:bg-slate-200 text-slate-600'}`}
                        >
                          <Minus size={16} />
                        </button>
                        <TypeIcon size={16} className={isDark ? 'text-white/30' : 'text-black/30'} />
                        <button
                          onClick={() => setFontSize(Math.min(32, fontSize + 2))}
                          className={`p-3 transition-colors ${isDark ? 'hover:bg-white/10 text-white/60' : 'hover:bg-slate-200 text-slate-600'}`}
                        >
                          <Plus size={16} />
                        </button>
                      </div>
                      <button
                        onClick={copyToClipboard}
                        className={`p-3 rounded-xl border transition-all ${copied
                          ? 'bg-green-500/20 border-green-500/30 text-green-500'
                          : isDark
                            ? 'bg-white/5 border-white/10 hover:bg-white/10 text-white/60 hover:text-white'
                            : 'bg-slate-100 border-slate-200 hover:bg-slate-200 text-slate-600 hover:text-slate-900'
                          }`}
                      >
                        {copied ? <Check size={18} /> : <Copy size={18} />}
                      </button>
                    </div>
                  </div>

                  {/* Title */}
                  <h1 className={`text-4xl sm:text-5xl lg:text-6xl font-bold ethiopic-font text-center leading-tight mb-16 ${isDark
                    ? 'text-transparent bg-clip-text bg-gradient-to-r from-white via-amber-100 to-white'
                    : 'text-transparent bg-clip-text bg-gradient-to-r from-slate-900 via-blue-800 to-slate-900'
                    }`}>
                    {currentMezmur?.title}
                  </h1>

                  {/* Lyrics */}
                  <div
                    className="space-y-8 ethiopic-font text-center leading-relaxed"
                    style={{ fontSize: `${fontSize}px` }}
                  >
                    {currentMezmur?.lyrics.map((line, idx) => {
                      const isChorus = line.includes('አዝ');
                      return (
                        <p
                          key={idx}
                          className={`transition-colors ${isChorus
                            ? `font-semibold py-6 px-8 rounded-2xl ${isDark
                              ? 'text-amber-300 bg-amber-500/10 border border-amber-500/20'
                              : 'text-blue-800 bg-blue-50 border border-blue-100'
                            }`
                            : isDark ? 'text-white/80' : 'text-slate-800'
                            }`}
                        >
                          {line}
                        </p>
                      );
                    })}
                  </div>

                  {/* Meaning Section */}
                  {currentMezmur?.meaning && (
                    <div className={`mt-20 p-8 sm:p-10 rounded-3xl relative overflow-hidden ${isDark
                      ? 'bg-gradient-to-br from-white/5 to-white/[0.02] border border-white/10'
                      : 'bg-gradient-to-br from-slate-50 to-white border border-slate-200'
                      }`}>
                      <div className={`absolute left-0 top-0 bottom-0 w-1 ${isDark
                        ? 'bg-gradient-to-b from-amber-500 to-purple-500'
                        : 'bg-gradient-to-b from-blue-400 to-indigo-400'
                        }`} />
                      <div className="flex items-center gap-3 mb-6">
                        <Info size={18} className={isDark ? 'text-amber-400' : 'text-blue-600'} />
                        <h3 className={`text-sm font-bold uppercase tracking-[0.2em] ${isDark ? 'text-amber-400' : 'text-blue-800'}`}>
                          Meaning
                        </h3>
                      </div>
                      <p className={`text-lg ethiopic-font leading-relaxed italic ${isDark ? 'text-white/60' : 'text-slate-600'}`}>
                        "{currentMezmur.meaning}"
                      </p>
                    </div>
                  )}
                </div>
              </article>

              {/* Quick Navigation */}
              <div className={`mt-8 p-6 rounded-2xl ${isDark
                ? 'bg-white/5 border border-white/10'
                : 'bg-white border border-slate-200 shadow-sm'
                }`}>
                <div className="flex items-center justify-between">
                  <button
                    onClick={() => handleSelectMezmur(Math.max(1, (currentMezmur?.id || 1) - 1))}
                    disabled={(currentMezmur?.id || 1) <= 1}
                    className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all ${(currentMezmur?.id || 1) <= 1
                      ? 'opacity-30 cursor-not-allowed'
                      : isDark
                        ? 'hover:bg-white/10 text-white/60 hover:text-white'
                        : 'hover:bg-slate-100 text-slate-600 hover:text-slate-900 border border-transparent hover:border-slate-200'
                      }`}
                  >
                    <ArrowLeft size={16} />
                    <span className="text-sm font-medium">Previous</span>
                  </button>
                  <span className={`text-sm ${isDark ? 'text-white/30' : 'text-slate-400'}`}>
                    {currentMezmur?.id} of {MEZMURS.length}
                  </span>
                  <button
                    onClick={() => handleSelectMezmur(Math.min(MEZMURS.length, (currentMezmur?.id || 1) + 1))}
                    disabled={(currentMezmur?.id || 1) >= MEZMURS.length}
                    className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all ${(currentMezmur?.id || 1) >= MEZMURS.length
                      ? 'opacity-30 cursor-not-allowed'
                      : isDark
                        ? 'hover:bg-white/10 text-white/60 hover:text-white'
                        : 'hover:bg-slate-100 text-slate-600 hover:text-slate-900 border border-transparent hover:border-slate-200'
                      }`}
                  >
                    <span className="text-sm font-medium">Next</span>
                    <ChevronRight size={16} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className={`relative z-10 mt-20 py-12 border-t ${isDark ? 'border-white/5' : 'border-slate-200'
        }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col items-center text-center gap-4">
            <div className={`p-3 rounded-2xl ${isDark
              ? 'bg-gradient-to-br from-amber-500/20 to-orange-600/10 border border-amber-500/20'
              : 'bg-gradient-to-br from-blue-100/50 to-indigo-100/50 border border-blue-200/50'
              }`}>
              <BookOpen className={isDark ? 'text-amber-400' : 'text-blue-800'} size={24} />
            </div>
            <div>
              <p className={`text-sm font-medium ${isDark ? 'text-white/60' : 'text-slate-600'}`}>
                Bole Debre Salem St. Stephen Cathedral
              </p>
              <p className={`text-xs mt-1 ${isDark ? 'text-white/30' : 'text-slate-400'}`}>
                Digital Hymnal Collection • Made with <Heart size={12} className="inline text-red-400" /> for the faithful
              </p>
            </div>
          </div>
        </div>
      </footer>

      {/* Global Styles */}
      <style dangerouslySetInnerHTML={{
        __html: `
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
        
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-20px) rotate(3deg); }
        }
        
        @keyframes float-delayed {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-15px) rotate(-2deg); }
        }
        
        @keyframes pulse-slow {
          0%, 100% { opacity: 0.3; transform: scale(1); }
          50% { opacity: 0.6; transform: scale(1.05); }
        }
        
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        
        .animate-float {
          animation: float 8s ease-in-out infinite;
        }
        
        .animate-float-delayed {
          animation: float-delayed 10s ease-in-out infinite;
          animation-delay: 2s;
        }
        
        .animate-pulse-slow {
          animation: pulse-slow 6s ease-in-out infinite;
        }
        
        .animate-fadeIn {
          animation: fadeIn 0.6s ease-out forwards;
        }
        
        body {
          font-family: 'Inter', system-ui, -apple-system, sans-serif;
        }
        
        .ethiopic-font {
          font-family: 'Noto Sans Ethiopic', 'Inter', sans-serif;
        }
        
        ::-webkit-scrollbar {
          width: 8px;
        }
        
        ::-webkit-scrollbar-track {
          background: transparent;
        }
        
        ::-webkit-scrollbar-thumb {
          background: rgba(148, 163, 184, 0.5);
          border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
          background: rgba(100, 116, 139, 0.8);
        }
        
        .custom-scrollbar::-webkit-scrollbar {
          width: 4px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: rgba(128, 128, 128, 0.2);
          border-radius: 2px;
        }
        
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: rgba(128, 128, 128, 0.4);
        }
      `}} />
    </div>
  );
};

export default App;
