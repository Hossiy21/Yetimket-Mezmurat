
export interface Mezmur {
  id: number;
  title: string;
  lyrics: string[];
  meaning?: string;
  category?: string;
}

export enum Theme {
  LIGHT = 'light',
  DARK = 'dark'
}
